 "use client";

import { useMemo, useState } from "react";

type RGB = { r: number; g: number; b: number };
const clamp = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
const hexToRgb = (hex: string): RGB | null => {
  let h = hex.replace("#", "").trim();
  if (/^[0-9a-fA-F]{3}$/.test(h)) h = h.split("").map(x => x + x).join("");
  if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
  return { r: parseInt(h.slice(0,2),16), g: parseInt(h.slice(2,4),16), b: parseInt(h.slice(4,6),16) };
};
const rgbToHex = ({r,g,b}: RGB) => "#" + [r,g,b].map(v => clamp(v).toString(16).padStart(2,"0")).join("").toUpperCase();
const rgbToHsl = ({r,g,b}: RGB) => {
  let rr=r/255, gg=g/255, bb=b/255, max=Math.max(rr,gg,bb), min=Math.min(rr,gg,bb), h=0, s=0, l=(max+min)/2;
  if(max!==min){ const d=max-min; s=l>0.5?d/(2-max-min):d/(max+min); switch(max){case rr:h=(gg-bb)/d+(gg<bb?6:0);break;case gg:h=(bb-rr)/d+2;break;default:h=(rr-gg)/d+4;} h*=60; }
  return {h:Math.round(h),s:Math.round(s*100),l:Math.round(l*100)};
};
const hslToRgb = (h:number,s:number,l:number):RGB => {
  s/=100;l/=100; const k=(n:number)=>(n+h/30)%12, a=s*Math.min(l,1-l);
  const f=(n:number)=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));
  return {r:Math.round(255*f(0)),g:Math.round(255*f(8)),b:Math.round(255*f(4))};
};
const luminance = (c:RGB) => {
  const vals=[c.r,c.g,c.b].map(v=>{v/=255;return v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4)});
  return .2126*vals[0]+.7152*vals[1]+.0722*vals[2];
};
const contrast = (a:RGB,b:RGB) => {const x=luminance(a),y=luminance(b);return ((Math.max(x,y)+.05)/(Math.min(x,y)+.05)).toFixed(2)};
const randomHex = () => rgbToHex({r:Math.random()*256,g:Math.random()*256,b:Math.random()*256});
const mix = (a:RGB,b:RGB,t:number):RGB => ({r:clamp(a.r+(b.r-a.r)*t),g:clamp(a.g+(b.g-a.g)*t),b:clamp(a.b+(b.b-a.b)*t)});
const copy = async (s:string) => { try { await navigator.clipboard.writeText(s); } catch {} };

const tools = [
  ["HEX to RGB","Convert HEX codes into RGB values."],["RGB to HEX","Convert RGB values into HEX."],["HEX to HSL","Get hue, saturation and lightness."],
  ["Color Picker","Pick a color visually."],["Palette Generator","Create a five-color palette."],["Gradient Generator","Build CSS gradients."],
  ["Contrast Checker","Check WCAG text contrast."],["Shades Generator","Create darker color variations."],["Tints Generator","Create lighter color variations."],
  ["Color Blender","Blend two colors."],["Color Inverter","Find the inverted color."],["Random Color","Generate a random color."],
  ["Complementary Color","Find the opposite hue."],["Analogous Palette","Create neighboring hues."],["Triadic Palette","Create three evenly spaced hues."],
  ["Monochromatic Palette","Create a single-hue palette."],["Color Temperature","Explore warm and cool color values."],["Color Name Helper","Get a simple descriptive color label."],
  ["CSS Variables","Export a CSS custom property."],["Color Code Export","Copy HEX, RGB and HSL values."]
] as const;

export default function Home() {
  const [hex,setHex]=useState("#6C63FF");
  const [second,setSecond]=useState("#FFB86B");
  const [bg,setBg]=useState("#FFFFFF");
  const [tool,setTool]=useState("Palette Generator");
  const [angle,setAngle]=useState(135);
  const [paletteSeed,setPaletteSeed]=useState(0);
  const [notice,setNotice]=useState("");
  const color=useMemo(()=>hexToRgb(hex),[hex]);
  const other=useMemo(()=>hexToRgb(second),[second]);
  const hsl=color?rgbToHsl(color):null;
  const palette=useMemo(()=>{
    if(!color)return [];
    const base=hsl!;
    if(tool==="Complementary Color") return [color,hslToRgb((base.h+180)%360,base.s,base.l)];
    if(tool==="Analogous Palette") return [-60,-30,0,30,60].map(d=>hslToRgb((base.h+d+360)%360,base.s,base.l));
    if(tool==="Triadic Palette") return [0,120,240].map(d=>hslToRgb((base.h+d)%360,base.s,base.l));
    if(tool==="Monochromatic Palette") return [20,35,50,65,80].map(l=>hslToRgb(base.h,base.s,l));
    return [-2,-1,0,1,2].map(d=>mix(color,{r:255,g:255,b:255},Math.max(0,d*.22)).r===-1?color: d<0?mix(color,{r:0,g:0,b:0},-d*.18):mix(color,{r:255,g:255,b:255},d*.18));
  },[color,tool,paletteSeed]);
  const gradient=`linear-gradient(${angle}deg, ${hex}, ${second})`;
  const show=(s:string)=>{setNotice(s);setTimeout(()=>setNotice(""),1800)};
  const updateHex=(v:string)=>setHex(v.startsWith("#")?v:"#"+v);
  const downloadPalette=()=>{
    const css=`:root {\n${palette.map((c,i)=>`  --color-${i+1}: ${rgbToHex(c)};`).join("\n")}\n}`;
    const blob=new Blob([css],{type:"text/css"}); const url=URL.createObjectURL(blob); const a=document.createElement("a");a.href=url;a.download="colorverse-palette.css";a.click();URL.revokeObjectURL(url);
  };
  const rgb=color?`rgb(${color.r}, ${color.g}, ${color.b})`:"Invalid color";
  const hslText=hsl?`hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`:"Invalid color";
  const contrastValue=color&&hexToRgb(bg)?contrast(color,hexToRgb(bg)!):"—";
  const ratio=Number(contrastValue);
  const toolDescription=tools.find(t=>t[0]===tool)?.[1] ?? "Explore color values and tools.";
  return <main>
    <header className="topbar"><a className="brand" href="#"><span className="brandmark">C</span> ColorVerse</a><nav><a href="#tools">Tools</a><a href="#explore">Explore</a><a href="#about">About</a></nav><a className="header-cta" href="#tools">Start creating <span>↗</span></a></header>
    <section className="hero">
      <div className="hero-copy"><div className="eyebrow"><span className="spark">✦</span> THE COLOR WORKSPACE FOR EVERYONE</div><h1>Every color has<br/><em>a story.</em></h1><p>Explore color, build beautiful palettes, and create gradients with a free toolkit made for designers, developers and curious minds.</p><div className="hero-actions"><a className="primary" href="#tools">Explore color tools <span>→</span></a><a className="secondary" href="#explore">Discover colors</a></div><div className="hero-proof"><span className="proof-dots"><i/><i/><i/></span> Free tools. No sign-up. No fuss.</div></div>
      <div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="color-card"><div className="big-swatch" style={{background:hex}}/><div className="swatch-info"><div><b>{hex.toUpperCase()}</b><small>YOUR COLOR OF THE MOMENT</small></div><button onClick={()=>copy(hex)} aria-label="Copy color">▢</button></div><div className="mini-swatches">{["#FFB86B","#A8E6CF","#F6A6C1","#292B3A"].map(c=><button key={c} style={{background:c}} onClick={()=>setHex(c)}/>)}</div></div><div className="floating-chip chip-top">✦ Color harmony</div><div className="floating-chip chip-bottom">HEX · RGB · HSL</div></div>
    </section>
    <section className="quickbar"><div><span className="quick-icon">◉</span><b>Instant conversions</b><small>Switch formats in a click</small></div><div><span className="quick-icon">▦</span><b>Palette inspiration</b><small>Find your perfect match</small></div><div><span className="quick-icon">◒</span><b>Designer-friendly</b><small>Copy-ready code snippets</small></div></section>
    <section className="workspace" id="tools"><div className="section-heading"><div><div className="eyebrow">YOUR CREATIVE WORKSPACE</div><h2>Make something <em>colorful.</em></h2><p>Pick a tool and start experimenting. Everything runs right in your browser.</p></div><span className="tool-count">20 FREE TOOLS</span></div>
      <div className="tool-layout"><aside className="tool-list"><div className="tool-list-title">COLOR TOOLS <span>20</span></div>{tools.map(([name],i)=><button key={name} className={tool===name?"active":""} onClick={()=>setTool(name)}><span className="tool-number">{String(i+1).padStart(2,"0")}</span>{name}<span className="chevron">›</span></button>)}</aside>
      <div className="tool-panel"><div className="panel-head"><div><div className="eyebrow">COLORVERSE TOOL</div><h3>{tool}</h3><p>{toolDescription}</p></div><span className="live-pill"><i/> LIVE TOOL</span></div>
        <div className="input-grid"><label>Primary color<div className="color-input"><input type="color" value={color?rgbToHex(color):"#000000"} onChange={e=>setHex(e.target.value)}/><input value={hex} onChange={e=>updateHex(e.target.value)} spellCheck={false}/></div></label>
        <label>Secondary / background<div className="color-input"><input type="color" value={hexToRgb(second)?second:"#ffffff"} onChange={e=>setSecond(e.target.value)}/><input value={second} onChange={e=>setSecond(e.target.value)}/></div></label></div>
        {tool==="Gradient Generator"?<div className="result-block"><div className="gradient-preview" style={{background:gradient}}/><label className="range-label">Gradient angle <b>{angle}°</b></label><input className="range" type="range" min="0" max="360" value={angle} onChange={e=>setAngle(Number(e.target.value))}/><div className="code-row"><code>background: {gradient};</code><button onClick={()=>{copy(`background: ${gradient};`);show("CSS copied")}}>Copy CSS</button></div></div>:
        tool==="Contrast Checker"?<div className="result-block"><label>Text color <input className="small-text" value={hex} onChange={e=>updateHex(e.target.value)}/></label><label>Background color <input className="small-text" value={bg} onChange={e=>setBg(e.target.value)}/></label><div className="contrast-preview" style={{color:hex,background:bg}}>The quick brown fox jumps over the lazy dog.</div><div className="contrast-result"><b>{contrastValue}:1</b><span className={ratio>=7?"pass":ratio>=4.5?"pass":"fail"}>{ratio>=7?"WCAG AAA":ratio>=4.5?"WCAG AA":"Needs improvement"}</span></div></div>:
        tool==="Color Blender"?<div className="result-block"><div className="blend-preview" style={{background:other&&color?`linear-gradient(90deg,${hex},${second})`:"transparent"}}/><div className="result-value"><b>{color&&other?rgbToHex(mix(color,other,.5)):"Enter valid HEX colors"}</b><button onClick={()=>color&&other&&copy(rgbToHex(mix(color,other,.5)))}>Copy result</button></div></div>:
        tool==="Color Inverter"?<div className="result-block"><div className="two-swatches"><div style={{background:hex}}/><div style={{background:color?rgbToHex({r:255-color.r,g:255-color.g,b:255-color.b}):"#fff"}}/></div><div className="result-value"><b>{color?rgbToHex({r:255-color.r,g:255-color.g,b:255-color.b}):"Invalid HEX"}</b><button onClick={()=>color&&copy(rgbToHex({r:255-color.r,g:255-color.g,b:255-color.b}))}>Copy result</button></div></div>:
        <div className="result-block"><div className="palette-grid">{palette.map((c,i)=><button key={i} className="palette-swatch" style={{background:rgbToHex(c)}} onClick={()=>{setHex(rgbToHex(c));show("Color selected")}}><span>{rgbToHex(c)}</span></button>)}</div><div className="palette-actions"><button className="outline-btn" onClick={()=>{setPaletteSeed(p=>p+1);if(tool==="Random Color")setHex(randomHex());show("New colors generated")}}>↻ Generate</button><button className="solid-btn" onClick={downloadPalette}>↓ Export CSS</button></div></div>}
        <div className="format-grid"><div><small>HEX</small><b>{color?rgbToHex(color):"—"}</b><button onClick={()=>color&&copy(rgbToHex(color))}>Copy</button></div><div><small>RGB</small><b>{rgb}</b><button onClick={()=>color&&copy(rgb)}>Copy</button></div><div><small>HSL</small><b>{hslText}</b><button onClick={()=>color&&copy(hslText)}>Copy</button></div></div>
        {notice&&<div className="toast">{notice}</div>}
      </div></div>
    </section>
    <section className="explore" id="explore"><div className="section-heading"><div><div className="eyebrow">A LITTLE COLOR INSPIRATION</div><h2>Explore the <em>spectrum.</em></h2><p>Start with a hue. Follow the feeling.</p></div></div><div className="spectrum">{["#FF6B6B","#FFB86B","#F9E27D","#A8E6CF","#6BCBCE","#6C8CFF","#A78BFA","#E6A6D7"].map((c,i)=><button key={c} style={{background:c}} onClick={()=>{setHex(c);document.getElementById("tools")?.scrollIntoView({behavior:"smooth"})}} aria-label={`Select ${c}`}><span>{c}</span></button>)}</div></section>
    <section className="about" id="about"><div><div className="eyebrow">DESIGNED FOR YOUR NEXT IDEA</div><h2>Good design starts<br/>with <em>great color.</em></h2></div><p>ColorVerse brings everyday color workflows into one simple space. Convert, compare, experiment and export — without installing software or creating an account.</p></section>
    <footer><a className="brand" href="#"><span className="brandmark">C</span> ColorVerse</a><span>© {new Date().getFullYear()} ColorVerse. Built for curious creators.</span><div><a href="mailto:hello@example.com">Contact</a><a href="/privacy">Privacy</a></div></footer>
  </main>;
}
