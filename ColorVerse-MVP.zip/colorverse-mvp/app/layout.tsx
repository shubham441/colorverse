import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ColorVerse — Free Color Tools & Palette Generator",
  description: "Free online color tools: HEX, RGB, HSL conversion, palettes, gradients, contrast checking, shades and tints.",
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "ColorVerse — The Ultimate Color Toolkit",
    description: "Explore colors, build palettes and create gradients for your next design.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
