# ColorVerse MVP

A client-side color toolkit built with Next.js 14, TypeScript and CSS. Core color operations run in the browser; no database or paid API is required for the initial MVP.

## Included
- Responsive landing page and tool workspace
- HEX / RGB / HSL conversion display
- Color picker
- Palette generation (shades, tints, complementary, analogous, triadic, monochromatic)
- CSS gradient builder and export
- WCAG contrast ratio checker
- Color blender and inverter
- Random color generation
- CSS palette export
- 20-tool navigation catalogue

## Run locally
1. Install Node.js 20 LTS.
2. Extract this project.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open `http://localhost:3000`

## Production build
- `npm run build`
- Static export is generated in `out/` because `output: "export"` is enabled.

## Free/low-cost deployment
- Push this folder to a GitHub repository.
- Import the repository into Vercel, or deploy the generated `out/` folder to Cloudflare Pages.
- No environment variables are needed for the current MVP.

## Before public launch
1. Replace `https://example.com` in `app/layout.tsx` with the final domain.
2. Replace `hello@example.com` in the footer with a real support email.
3. Add real Privacy, Terms, Contact and About pages.
4. Add a sitemap and robots.txt with the final domain.
5. Test keyboard accessibility, color contrast, mobile layouts and all tool outputs.
6. Connect Google Search Console and analytics.
7. Apply for advertising only after the site has useful original content and is policy-compliant.

## Current limitations
- The tool catalogue contains 20 entries; several are MVP palette variations built on the shared color engine, not 20 separate advanced applications.
- The Color Name Helper is a placeholder-style tool entry and does not yet use a full color-name database.
- AI generation, image palette extraction, user accounts, saved projects, billing, and team features are not included yet.
- The starter uses Google Fonts via CSS import; replace with locally hosted fonts if a fully self-hosted deployment is required.
